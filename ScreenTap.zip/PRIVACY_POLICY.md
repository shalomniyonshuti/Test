# Privacy Policy – Rwanda Music

Last updated: 2026-10-16

Rwanda Music ("the app") plays music videos from YouTube and lists songs and singers.

**Data we collect.** The app does not create accounts and does not sell data. If you choose to sign in with Google, the app receives a temporary access token to read your YouTube subscriptions and to like videos on your behalf. The token is kept only in memory/session on your device.

**On your device.** Settings such as theme and cached lists are stored locally on your device.

**Third parties.** Videos are played with the YouTube embedded player and data is requested through YouTube API Services. By using the app you agree to the [YouTube Terms of Service](https://www.youtube.com/t/terms) and the [Google Privacy Policy](https://policies.google.com/privacy). You can revoke access at https://security.google.com/settings/security/permissions.

**Children.** The app is not directed to children under 13.

**Contact.** Replace this line with your e-mail address.
