package com.example.screentap

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView

    private fun canOverlay() = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(p, p, p, p)
        }
        root.addView(TextView(this).apply { text = "ScreenTap"; textSize = 28f })
        status = TextView(this).apply { textSize = 16f; setPadding(0, p / 2, 0, p) }
        root.addView(status)
        fun btn(label: String, action: () -> Unit) {
            root.addView(Button(this).apply { text = label; setOnClickListener { action() } })
        }
        btn("1. Allow display over other apps") {
            if (canOverlay()) toast("Already allowed")
            else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("2. Allow running in background") {
            if (Build.VERSION.SDK_INT >= 23) {
                val pm = getSystemService(POWER_SERVICE) as PowerManager
                if (!pm.isIgnoringBatteryOptimizations(packageName))
                    startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                else toast("Already allowed")
            }
        }
        btn("3. Start floating button") { start() }
        btn("Stop") { stopService(Intent(this, FloatService::class.java)); onResume() }
        setContentView(root)
    }

    private fun start() {
        if (!canOverlay()) { toast("Do step 1 first"); return }
        if (Build.VERSION.SDK_INT in 23..28 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 2)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3)
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 1)
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(rc, perms, res)
        if (rc == 2 && res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED) start()
        else if (rc == 3) start()
        else toast("Permission needed to save screenshots")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rc: Int, result: Int, data: Intent?) {
        super.onActivityResult(rc, result, data)
        if (rc == 1) {
            if (result == RESULT_OK && data != null) {
                val i = Intent(this, FloatService::class.java)
                    .putExtra(FloatService.EXTRA_CODE, result).putExtra(FloatService.EXTRA_DATA, data)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                moveTaskToBack(true)
            } else toast("Screen capture was not allowed")
        }
    }

    override fun onResume() {
        super.onResume()
        status.text = when {
            FloatService.running -> "✅ Running. A blue button floats over apps. Tap it to take a screenshot; drag to move it."
            !canOverlay() -> "⚠️ Do step 1, then 2, then 3."
            else -> "Ready. Tap step 3 to start."
        }
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
}
