package com.example.screentap

import android.app.*
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.MediaScannerConnection
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

class FloatService : Service() {
    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        @Volatile var running = false
    }

    private lateinit var wm: WindowManager
    private var button: ImageView? = null
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var held: Image? = null
    private val handler = Handler(Looper.getMainLooper())
    private var w = 0; private var h = 0; private var dpi = 0

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i == null) { stopSelf(); return START_NOT_STICKY }
        if (running) return START_NOT_STICKY
        startFg()
        try {
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val code = i.getIntExtra(EXTRA_CODE, 0)
            @Suppress("DEPRECATION")
            val data = i.getParcelableExtra<Intent>(EXTRA_DATA)!!
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = mpm.getMediaProjection(code, data)
            projection = p
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { handler.post { stopSelf() } }
            }, handler)
            measure()
            reader = newReader()
            vd = p.createVirtualDisplay("ScreenTap", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler)
            addButton()
            running = true
        } catch (e: Exception) {
            toast("Start failed: ${e.message}")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(NotificationChannel("shot", "ScreenTap", NotificationManager.IMPORTANCE_LOW))
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "shot") else Notification.Builder(this)
        val n = b.setContentTitle("ScreenTap is running")
            .setContentText("Tap the floating button to take a screenshot")
            .setSmallIcon(android.R.drawable.ic_menu_camera).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun measure() {
        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(m)
        w = m.widthPixels; h = m.heightPixels; dpi = m.densityDpi
    }

    private fun newReader(): ImageReader {
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        r.setOnImageAvailableListener({ rd ->
            val img = try { rd.acquireLatestImage() } catch (e: Exception) { null }
            if (img != null) { held?.close(); held = img }
        }, handler)
        return r
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        if (vd == null) return
        val oldW = w; val oldH = h
        measure()
        if (oldW == w && oldH == h) return
        val old = reader
        held?.close(); held = null
        reader = newReader()
        vd?.resize(w, h, dpi)
        vd?.surface = reader!!.surface
        old?.close()
    }

    private fun addButton() {
        val d = resources.displayMetrics.density
        val size = (52 * d).toInt()
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(size, size, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = (200 * d).toInt() }
        val v = ImageView(this).apply {
            setImageResource(R.drawable.ic_launcher)
            alpha = 0.85f
        }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true
                    if (moved) { lp.x = ox + dx; lp.y = oy + dy; wm.updateViewLayout(v, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) capture()
            }
            true
        }
        wm.addView(v, lp)
        button = v
    }

    private fun capture() {
        val v = button ?: return
        v.visibility = View.INVISIBLE
        handler.postDelayed({
            val img = held
            if (img == null) {
                v.visibility = View.VISIBLE
                toast("No frame yet, try again")
            } else {
                try {
                    val bmp = toBitmap(img)
                    v.visibility = View.VISIBLE
                    save(bmp)
                } catch (e: Exception) {
                    v.visibility = View.VISIBLE
                    toast("Capture failed: ${e.message}")
                }
            }
        }, 350)
    }

    private fun toBitmap(img: Image): Bitmap {
        val p = img.planes[0]
        val rowPad = p.rowStride - p.pixelStride * img.width
        val full = Bitmap.createBitmap(img.width + rowPad / p.pixelStride, img.height, Bitmap.Config.ARGB_8888)
        p.buffer.rewind()
        full.copyPixelsFromBuffer(p.buffer)
        return if (rowPad == 0) full else Bitmap.createBitmap(full, 0, 0, img.width, img.height)
    }

    private fun save(bmp: Bitmap) {
        Thread {
            try {
                val name = "ScreenTap_${System.currentTimeMillis()}.png"
                if (Build.VERSION.SDK_INT >= 29) {
                    val cv = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, name)
                        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ScreenTap")
                    }
                    val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)!!
                    contentResolver.openOutputStream(uri)!!.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                } else {
                    @Suppress("DEPRECATION")
                    val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "ScreenTap")
                    dir.mkdirs()
                    val f = File(dir, name)
                    FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    MediaScannerConnection.scanFile(this, arrayOf(f.absolutePath), null, null)
                }
                toast("Saved to Pictures/ScreenTap")
            } catch (e: Exception) {
                toast("Save failed: ${e.message}")
            }
        }.start()
    }

    private fun toast(t: String) { handler.post { Toast.makeText(applicationContext, t, Toast.LENGTH_SHORT).show() } }

    override fun onDestroy() {
        running = false
        button?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        button = null
        held?.close(); held = null
        vd?.release(); vd = null
        reader?.close(); reader = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
        super.onDestroy()
    }
}
