# Rwanda Music – Android app (not a PWA)

Native Android project (Java, Android 8.0+ / API 26+, target API 36).
Your website (`index.html`) is bundled **inside** the app (`app/src/main/assets/www`) and shown in a
WebView under `https://rwandamusic.store/`, so YouTube embeds, API-key referrer rules and saved data work like on the website.
No manifest, no service worker, no install screen.

## 1. Upload to GitHub
1. Create a new repository on github.com.
2. Upload **all files of this folder** (keep the folder structure, including `.github`).
3. Open the **Actions** tab. The workflow *Build Android app* runs by itself and gives you
   **RwandaMusic-debug-apk** (install on a phone to test).

## 2. Make the file for Google Play (.aab) – one time setup
Google Play needs a signed **.aab**. Create your upload key once (needs Java installed):

    keytool -genkeypair -v -keystore upload.keystore -alias upload -keyalg RSA -keysize 2048 -validity 10000

**Keep `upload.keystore` and its passwords safe – never lose them, never upload to GitHub.**

Convert it to text and add 4 repository secrets (GitHub → Settings → Secrets and variables → Actions):

| Secret | Value |
|---|---|
| `KEYSTORE_BASE64` | output of `base64 -w0 upload.keystore` |
| `KEYSTORE_PASSWORD` | keystore password |
| `KEY_ALIAS` | `upload` |
| `KEY_PASSWORD` | key password |

Run **Actions → Build Android app → Run workflow**. Download **RwandaMusic-release-aab-for-Google-Play**
and upload the `.aab` in Play Console (Production or Internal testing). Turn on **Play App Signing** when asked.

For each new upload raise `versionCode` in `app/build.gradle`.

## 3. Google sign-in (YouTube subscriptions / likes)
Sign-in is native (Google Authorization API). It needs an **Android OAuth client**:
1. Google Cloud Console → project of your OAuth client → APIs & Services → Credentials → *Create credentials → OAuth client ID → Android*.
2. Package name: `store.rwandamusic.app`
3. SHA-1: add the SHA-1 of your **upload key** (`keytool -list -v -keystore upload.keystore`) **and** the
   **App signing key** SHA-1 shown in Play Console → Setup → App signing.
4. Add the scope `.../auth/youtube` on the OAuth consent screen.
Without this, the app works fully; only the Sign-in button will fail.

## 4. Play Console checklist
- Icon 512×512: `store-assets/play-icon-512.png`; feature graphic: `store-assets/feature-graphic-1024x500.png`
- Privacy policy URL is required (template: `PRIVACY_POLICY.md` – host it on your site).
- Data safety form: app uses internet, Google account sign-in (optional), YouTube API Services.
- Follow YouTube API Services Terms: audio stops when the app is not visible (the app pauses on purpose).
- Add at least 2 phone screenshots.

## Open in Android Studio
File → Open → this folder. Build → Generate App Bundles / APKs.
(If `gradlew` is missing, Android Studio uses Gradle 8.11.1 automatically, or run `gradle wrapper` once.)
